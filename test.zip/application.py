# -*- coding: utf-8 -*-

from flask import Flask
from flask import jsonify
from flask_caching import Cache
from wavedata import wavedata
import json

cache = Cache()
#Shops
chishops = [{"id": 0, "name": "Lake Effect", "city": "Shorewood, WI", "url": "https://www.lakeeffectsurfshop.com/"},{"id": 1, "name": "Third Coast", "city": "New Buffalo, MI", "url": "https://www.thirdcoastsurfshop.com/"}]
mkeshops = [{"id": 0, "name": "Lake Effect", "city": "Shorewood, WI", "url": "https://www.lakeeffectsurfshop.com/"}, {"id": 1, "name": "EOS", "city": "Sheboygan, WI", "url": "https://eossurf.com/"}]
shebshops = [{"id": 0, "name": "EOS", "city": "Sheboygan, WI", "https://eossurf.com/": "True"}, {"id": 1, "name": "Lake Effect", "city": "Shorewood, WI", "url": "https://www.lakeeffectsurfshop.com/"}]
stjshops = [{"id": 0, "name": "Third Coast", "city": "Saint Joseph, MI", "url": "https://www.lakeeffectsurfshop.com/"}]
micityshops = [{"id": 0, "name": "Third Coast", "city": "New Buffalo", "url": "https://www.lakeeffectsurfshop.com/"}, {"id": 1, "name": "Third Coast", "city": "Saint Joseph", "url": "https://www.lakeeffectsurfshop.com/"}] 

def create_app():
    application = app = Flask(__name__)

    app.config['JSONIFY_PRETTYPRINT_REGULAR'] = True

    app.config['CACHE_TYPE'] = 'simple'

    cache.init_app(app)

    @app.route('/')
    @cache.cached(timeout=1200)
    def home():
        return jsonify({"Hello World": "Hello"})

    

    return app

